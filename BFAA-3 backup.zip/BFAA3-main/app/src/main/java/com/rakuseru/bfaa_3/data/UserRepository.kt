package com.rakuseru.bfaa_3.data

import android.annotation.SuppressLint
import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.liveData
import androidx.lifecycle.map
import com.rakuseru.bfaa_3.data.local.entity.UserEntity
import com.rakuseru.bfaa_3.data.local.room.UserDao
import com.rakuseru.bfaa_3.data.remote.service.ApiService
import com.rakuseru.bfaa_3.utils.AppExecutors
import com.rakuseru.bfaa_3.utils.DateFormatter
import java.time.LocalDateTime

class UserRepository private constructor(
    private val apiService: ApiService,
    private val userDao: UserDao,
    private val appExecutors: AppExecutors
) {
    @SuppressLint("NewApi")
    fun getUsers(): LiveData<Result<List<UserEntity>>> = liveData {
        emit(Result.Loading)
        try {
            val response = apiService.getListUsers()
            val userList = response.map { user ->
                val isBookmarked = userDao.isUserBookmarked(user.login!!)
                val dateCreate = DateFormatter.formatDate(LocalDateTime.now().toString())
                UserEntity(
                    user.login,
                    user.avatarUrl,
                    user.followersUrl,
                    user.followingUrl,
                    user.name,
                    user.company,
                    user.blog,
                    user.location,
                    user.bio,
                    user.publicRepo,
                    user.followers,
                    user.following,
                    isBookmarked,
                    dateCreate
                )
            }
            userDao.deleteAll()
            userDao.insertUser(userList)

        } catch (e: Exception) {
            Log.d("UserRepository", "getUsers: ${e.message.toString()}")
            emit(Result.Error(e.message.toString()))
        }

        val localData: LiveData<Result<List<UserEntity>>> = userDao.getUsers().map { Result.Success(it) }
        emitSource(localData)
    }

    fun getBookmarkedUsers(): LiveData<List<UserEntity>> {
        return userDao.getBookmarked()
    }

    suspend fun setBookmark(user: UserEntity, bookmarkState: Boolean) {
        user.isBookmarked = bookmarkState
        userDao.updateUser(user)
    }

    companion object {
        @Volatile
        private var instance: UserRepository? = null
        fun getInstance(
            apiService: ApiService,
            userDao: UserDao,
            appExecutors: AppExecutors
        ): UserRepository =
            instance ?: synchronized(this) {
                instance ?: UserRepository(apiService, userDao, appExecutors)
            }.also { instance = it }
    }
}