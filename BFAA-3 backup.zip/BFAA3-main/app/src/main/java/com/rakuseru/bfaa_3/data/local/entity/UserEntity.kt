package com.rakuseru.bfaa_3.data.local.entity

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import java.sql.Timestamp

@Entity(tableName = "users")
class UserEntity (
    @field:ColumnInfo(name = "login")
    @field:PrimaryKey
    val login: String,

    @field:ColumnInfo(name = "avatar_url")
    val avatarUrl: String? = null,

    @field:ColumnInfo(name = "followers_url")
    val followersUrl: String? = null,

    @field:ColumnInfo(name = "following_url")
    val followingUrl: String? = null,

    @field:ColumnInfo(name = "name")
    val name: String? = null,

    @field:ColumnInfo(name = "company")
    val company: String? = null,

    @field:ColumnInfo(name = "blog")
    val blog: String? = null,

    @field:ColumnInfo(name = "location")
    val location: String? = null,

    @field:ColumnInfo(name = "bio")
    val bio: String? = null,

    @field:ColumnInfo(name = "public_repos")
    val publicRepo: String? = null,

    @field:ColumnInfo(name = "followers")
    val followers: String? = null,

    @field:ColumnInfo(name = "following")
    val following: String? = null,

    @field:ColumnInfo(name = "bookmarked")
    var isBookmarked: Boolean = false,

    @field:ColumnInfo(name = "created_at")
    var createdAt: String? = null
)