package com.rakuseru.bfaa_3.adapter

import com.rakuseru.bfaa_3.data.remote.response.UserResponse

interface OnItemClickCallback {
    fun onItemClicked(user: UserResponse)
}