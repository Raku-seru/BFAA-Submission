package com.rakuseru.bfaa_3.di

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import com.rakuseru.bfaa_3.data.local.room.UserDatabase
import com.rakuseru.bfaa_3.data.UserRepository
import com.rakuseru.bfaa_3.data.remote.service.ApiConfig
import com.rakuseru.bfaa_3.preferences.SettingPreferences
import com.rakuseru.bfaa_3.utils.AppExecutors

object Injection {
    fun provideRepository(context: Context): UserRepository {
        val apiService  = ApiConfig.getApiService()
        val database    = UserDatabase.getInstance(context)
        val dao = database.userDao()
        val appExecutors = AppExecutors()

        return UserRepository.getInstance(apiService, dao, appExecutors)
    }

    fun provideDatastore(pref: DataStore<Preferences>): SettingPreferences {
        return SettingPreferences.getInstance(pref)
    }

}