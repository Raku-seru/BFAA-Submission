package com.rakuseru.bfaa_3.data.local.room

import androidx.lifecycle.LiveData
import androidx.room.*
import com.rakuseru.bfaa_3.data.local.entity.UserEntity

@Dao
interface UserDao {
    @Query("SELECT * FROM users ORDER BY login DESC")
    fun getUsers(): LiveData<List<UserEntity>>

    @Query("SELECT * FROM users WHERE login = :login")
    fun getUserBySearch(login: String): LiveData<List<UserEntity>>

    @Query("SELECT * FROM users where bookmarked = 1")
    fun getBookmarked(): LiveData<List<UserEntity>>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertUser(user: List<UserEntity>)

    @Update
    suspend fun updateUser(user: UserEntity)

    @Query("DELETE FROM users WHERE bookmarked = 0")
    suspend fun deleteAll()

    @Query("SELECT EXISTS(SELECT * FROM users WHERE login = :login AND bookmarked = 1)")
    suspend fun isUserBookmarked(login: String): Boolean
}