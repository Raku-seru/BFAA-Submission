package com.rakuseru.bfaa_3.ui.main

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.lifecycle.ViewModel
import com.rakuseru.bfaa_3.preferences.SettingPreferences
import androidx.lifecycle.ViewModelProvider.NewInstanceFactory
import com.rakuseru.bfaa_3.data.UserRepository
import com.rakuseru.bfaa_3.di.Injection

class MainViewModelFactory(
    private val pref: SettingPreferences,
//    private val userRepository: UserRepository
    ): NewInstanceFactory() {

    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(MainViewModel::class.java)) {
            return MainViewModel(pref) as T
//            return MainViewModel(pref, userRepository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class: " + modelClass.name)
    }

//    companion object {
//        @Volatile
//        private var instance: MainViewModelFactory? = null
//        fun getInstance(pref: dataStore<Preferences>): MainViewModelFactory =
//            instance ?: synchronized(this) {
//                instance ?: MainViewModelFactory(Injection.provideDatastore(pref))
//                instance ?: MainViewModelFactory(Injection.provideDatastore(pref), Injection.provideRepository(context))
//            }.also { instance = it }
//    }
}