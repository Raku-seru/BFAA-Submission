package com.rakuseru.bfaa_3.ui.main

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.CompoundButton
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.appcompat.widget.SearchView
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.preferencesDataStore
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.GridLayoutManager
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.android.material.switchmaterial.SwitchMaterial
import com.rakuseru.bfaa_3.R
import com.rakuseru.bfaa_3.adapter.OnItemClickCallback
import com.rakuseru.bfaa_3.adapter.UserAdapter
import com.rakuseru.bfaa_3.databinding.ActivityMainBinding
import com.rakuseru.bfaa_3.data.remote.response.UserResponse
import com.rakuseru.bfaa_3.preferences.SettingPreferences
import com.rakuseru.bfaa_3.data.remote.service.NetworkConnection
import com.rakuseru.bfaa_3.ui.bookmark.BookmarkActivity
import com.rakuseru.bfaa_3.ui.userdetail.DetailUserActivity

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "settings")

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val adapter: UserAdapter by lazy {
        UserAdapter()
    }

    val mainViewModel: MainViewModel by viewModels {
        MainViewModelFactory(SettingPreferences.getInstance(dataStore))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val switchTheme = findViewById<SwitchMaterial>(R.id.switch_mode)

        mainViewModel.getThemeSetting().observe(this) { isDarkModeActive: Boolean ->
            if (isDarkModeActive) {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
                switchTheme.isChecked = true
            } else {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
                switchTheme.isChecked = false
            }
        }

        switchTheme.setOnCheckedChangeListener { _: CompoundButton?, isChecked: Boolean ->
            mainViewModel.saveThemeSetting(isChecked)
        }

        val fabBookmark = findViewById<FloatingActionButton>(R.id.fab_star)

        fabBookmark.setOnClickListener {
            startActivity(Intent(applicationContext, BookmarkActivity::class.java))
        }

        // Setting up application
        setupSearchView()
        observeAnimationAndProgressBar()
        checkInternetConnection()

    }

    private fun setupSearchView() {
        with(binding) {
            searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
                override fun onQueryTextSubmit(query: String): Boolean {
                    showFailedLoadData(false)
                    showProgressBar(true)

                    mainViewModel.getUserBySearch(query)
                    mainViewModel.searchUser.observe(this@MainActivity) { searchUserResponse ->
                        if (searchUserResponse != null) {
                            adapter.addDataToList(searchUserResponse)
                            setUserData()
                        }
                    }
                    return true
                }

                override fun onQueryTextChange(newText: String?): Boolean {
                    return false
                }
            })
        }
    }

    private fun observeAnimationAndProgressBar() {
        mainViewModel.isLoading.observe(this) {
            showProgressBar(it)
        }
        mainViewModel.isDataFailed.observe(this) {
            showFailedLoadData(it)
        }
    }

    private fun checkInternetConnection() {
        val networkConnection = NetworkConnection(applicationContext)
        networkConnection.observe(this) { isConnected ->
            if (isConnected) {
                showFailedLoadData(false)
                mainViewModel.user.observe(this) { userResponse ->
                    if (userResponse != null) {
                        adapter.addDataToList(userResponse)
                        setUserData()
                    }
                }
                mainViewModel.searchUser.observe(this@MainActivity) { searchUserResponse ->
                    if (searchUserResponse != null) {
                        adapter.addDataToList(searchUserResponse)
                        binding.rvUsers.visibility = View.VISIBLE
                    }
                }
            } else {
                mainViewModel.user.observe(this) { userResponse ->
                    if (userResponse != null) {
                        adapter.addDataToList(userResponse)
                        setUserData()
                    }
                }
                mainViewModel.searchUser.observe(this@MainActivity) { searchUserResponse ->
                    if (searchUserResponse != null) {
                        adapter.addDataToList(searchUserResponse)
                        binding.rvUsers.visibility = View.VISIBLE
                    }
                }
                Toast.makeText(
                    this@MainActivity,
                    getString(R.string.no_internet),
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }

    // to Hide Recycler view showing list
    private fun hideUserList() {
        binding.rvUsers.layoutManager = null
        binding.rvUsers.adapter = null
    }

    // Loading bar controller
    private fun showProgressBar(isLoading: Boolean) {
        binding.pbLoading.visibility = if (isLoading) View.VISIBLE else View.GONE
    }

    // Failed text controller
    private fun showFailedLoadData(isFailed: Boolean) {
        binding.tvFailed.visibility = if (isFailed) View.VISIBLE else View.GONE
    }

    private fun setUserData() {
        val layoutManager =
            GridLayoutManager(this@MainActivity, 1, GridLayoutManager.VERTICAL, false)
        binding.rvUsers.layoutManager = layoutManager
        binding.rvUsers.adapter = adapter
//        binding.rvUsers.setHasFixedSize(true)

        adapter.setOnItemClickCallback(object : OnItemClickCallback {
            override fun onItemClicked(user: UserResponse) {
                hideUserList()
                val intent = Intent(this@MainActivity, DetailUserActivity::class.java)
                intent.putExtra(DetailUserActivity.KEY_USER, user)
                startActivity(intent)
            }
        })
    }
}